for f in `ls -1 nationals2016/pilot_p*s15.htm.yml` ; \
  do sed -i -e '3 s/Free Unknown Sequence/Programme 3: Free Unknown #2/' $f ; \
done
for f in `ls -1 nationals2016/pilot_p*s17.htm.yml` ; \
  do sed -i -e '3 s/Free Sequence/Programme 2/' $f ; \
done
for f in `ls -1 nationals2016/pilot_p*s18.htm.yml` ; \
  do sed -i -e '3 s/Free Sequence/Programme 3/' $f ; \
done
for f in `ls -1 nationals2016/pilot_p*s05.htm.yml` ; \
  do sed -i -e '3 s/Free Sequence/Programme 2/' $f ; \
done
for f in `ls -1 nationals2016/pilot_p*s06.htm.yml` ; \
  do sed -i -e '3 s/Free Sequence/Programme 3/' $f ; \
done
for f in `ls -1 nationals2016/pilot_p*s02.htm.yml` ; \
  do sed -i -e '3 s/1st Known Sequence/Programme 2/' $f ; \
done
for f in `ls -1 nationals2016/pilot_p*s03.htm.yml` ; \
  do sed -i -e '3 s/2nd Known Sequence/Programme 3/' $f ; \
done
for f in `ls -1 nationals2016/pilot_p*s24.htm.yml` ; \
  do sed -i -e '3 s/Free Unknown Sequence/2nd Free Unknown/' $f ; \
done

