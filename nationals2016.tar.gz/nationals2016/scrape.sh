rails runner cmd/acro/scrape_html_to_yaml.rb \
  nationals2016/www.iac.org/files/nationals-results/2016/contest.yml
mv nationals2016/www.iac.org/files/nationals-results/2016/*.yml nationals2016
